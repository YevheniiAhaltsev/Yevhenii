// NAVIGATION
const mainNav = document.querySelector(".nav")
const btnNav = document.querySelector(".burger")
btnNav.addEventListener('click', () => {
  console.log("click")
  btnNav.classList.toggle("nav-act");
  mainNav.classList.toggle("active");
})
// TEXT GREETINGS
const spnText = document.querySelector('.text');
const spnCursor = document.querySelector('.cursor');
const txt = ["It's nice to see you here!!!", 'Welcome!!!']
let activeLetter = -15;
let activeText = 0;
const addLetter = () => {
  if (activeLetter >= 0) {
    spnText.textContent += txt[activeText][activeLetter];
  }
  activeLetter++;
  if (activeLetter === txt[activeText].length) {
    activeText++;
    if (activeText === txt.length) return;
    return setTimeout(() => {
      activeLetter = -15;
      spnText.textContent = '';
      addLetter();
    }, 2000)
  }
  setTimeout(addLetter, 100)
}
addLetter();

// AnimaTION CURSOR
const cursorAnimation = () => {
  spnCursor.classList.toggle('active');
}
setInterval(cursorAnimation, 400);

// SCROLLING  
document.addEventListener('DOMContentLoaded', function () {
  const scrolls = document.querySelectorAll(".scroll");

  for (let i = 0; i < scrolls.length; i++) {
    scrolls[i].addEventListener('click', function (event) {
      event.preventDefault();

      const blockID = event.target.getAttribute("href").substr(1)

      document.getElementById(blockID).scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
      btnNav.classList.remove("nav-act");
      mainNav.classList.remove("active");
    });
  }
});